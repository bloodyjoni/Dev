/** Automatically generated file. DO NOT MODIFY */
package com.example.hellogap;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}