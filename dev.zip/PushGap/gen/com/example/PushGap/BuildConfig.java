/** Automatically generated file. DO NOT MODIFY */
package com.example.PushGap;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}